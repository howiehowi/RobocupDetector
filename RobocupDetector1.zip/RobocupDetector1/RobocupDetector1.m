img = imread('Image_20240119T235456.png');
load('RobocupDetector1');
%trained by 500 imgs, 40mini-batch
[bboxes, scores, labels] = detect(trainedDetector, img);

%remove scores below 0.9 accuracy
high_score_indices = scores >= 0.9;
bboxes = bboxes(high_score_indices, :);
scores = scores(high_score_indices);
labels = labels(high_score_indices); 

classNames = trainedDetector.ClassNames;
labelStrs = classNames(labels);
annotations = strcat(labelStrs, ': ', string(scores));
I1 = insertObjectAnnotation(img, 'rectangle', bboxes, annotations);

[m, n] = size(bboxes);
centers = zeros(m, 2);
mat=zeros(m);
for i = 1:m
    centers(i, 1) = bboxes(i, 1) + (bboxes(i, 3) / 2);
    centers(i, 2) = bboxes(i, 2) + (bboxes(i, 4) / 2);
    y(i)=-centers(i,1);
    x(i)=centers(i,2);
end


figure;
imshow(I1);
hold on;
for i = 1:m
    plot(centers(i, 1), centers(i, 2), 'b*');
    text(centers(i, 1), centers(i, 2), sprintf('(%0.2f, %0.2f)', centers(i, 1), centers(i, 2)), 'Color', 'yellow', 'FontSize', 8);
end
